
from flask import Flask, render_template, request, redirect, url_for
import os
from PIL import Image
import numpy as np
import cv2

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def predict_trend_from_image(img_path):
    # Read image
    img = cv2.imread(img_path)
    if img is None:
        return {"error":"cannot read image"}
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # crop center area to focus on chart
    h,w = gray.shape
    cy1, cy2 = int(h*0.05), int(h*0.95)
    cx1, cx2 = int(w*0.05), int(w*0.95)
    cropped = gray[cy1:cy2, cx1:cx2]
    # blur + edges
    blur = cv2.GaussianBlur(cropped, (5,5), 0)
    edges = cv2.Canny(blur, 50, 150)
    # Hough lines
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50, minLineLength=30, maxLineGap=10)
    slopes = []
    lengths = []
    if lines is not None:
        for l in lines:
            x1,y1,x2,y2 = l[0]
            dx = x2 - x1
            dy = y2 - y1
            if dx == 0:
                continue
            slope = dy/dx
            length = np.hypot(dx,dy)
            # ignore near-vertical lines
            if abs(slope) > 5:
                continue
            slopes.append(slope)
            lengths.append(length)
    if not slopes:
        return {"trend":"Sideways","confidence":0.35,"avg_slope":0.0}
    # Weighted average of slopes by length
    slopes = np.array(slopes)
    lengths = np.array(lengths)
    avg_slope = np.sum(slopes * lengths) / (np.sum(lengths) + 1e-9)
    # Map slope to prediction
    # positive slope (image coordinates: y grows downward) => negative slope means uptrend visually
    # Because image y increases downwards, negative slope indicates upward price.
    visual_slope = -avg_slope
    conf = min(0.95, 0.4 + min(1.0, abs(visual_slope)*1.5))
    if visual_slope > 0.04:
        trend = "UP"
    elif visual_slope < -0.04:
        trend = "DOWN"
    else:
        trend = "SIDEWAYS"
    return {"trend":trend, "confidence": round(float(conf),2), "avg_slope": float(visual_slope)}

@app.route("/")
def index():
    # show sample image path (local path from upload history)
    sample_path = "/static/sample_input.png"
    return render_template("index.html", sample_path=sample_path)

@app.route("/upload", methods=["POST"])
def upload():
    f = request.files.get("screenshot")
    if not f:
        return redirect(url_for('index'))
    filename = f.filename
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    f.save(save_path)
    result = predict_trend_from_image(save_path)
    return render_template("result.html", result=result, filename=os.path.join('static','uploads',filename))

if __name__ == "__main__":
    app.run(debug=True)
